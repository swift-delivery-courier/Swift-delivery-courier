# Browser-only deployment (no Command Prompt)

You will use three websites only:
1. neon.tech — free database
2. github.com — store your project files
3. render.com — run the website online

Do not share passwords, JWT secrets, or database URLs with anyone.

---

## Part 1 — Free database (Neon)

1. Open https://console.neon.tech and create a free account (email or Google).
2. Click **Create a project**.
3. Project name: `swift-delivery` (or any name). Keep the default region.
4. Click **Create project**.
5. On the next screen you will see a **Connection string**.
   - Click **Copy** to copy it.
   - It looks like: `postgresql://something:...@ep-....neon.tech/neondb?sslmode=require`
6. Paste it into a private note on your phone or a password manager.
   - You will paste this later into Render as `DATABASE_URL`.
   - Do not post it publicly.

---

## Part 2 — Put the project on GitHub

1. Open https://github.com and create a free account if you do not have one.
2. Click the **+** (top right) → **New repository**.
3. Repository name: `swift-delivery-courier`
4. Set to **Public** (needed for free Render in many cases).
5. Do **not** check “Add a README”.
6. Click **Create repository**.
7. On the empty repo page, click **uploading an existing file** (or “Add file” → “Upload files”).
8. On your computer, unzip `swift-delivery-courier.zip` so you see a folder with `server.js`, `package.json`, `views`, etc.
9. Open that folder, select **all** files and folders inside it (not the outer zip).
10. Drag them into the GitHub upload area.
11. Scroll down, type commit message: `Initial upload`
12. Click **Commit changes**.

If some nested folders fail to upload, create the folder on GitHub (“Add file” → “Create new file” → type `folder/name.txt`), then upload into it. Prefer uploading the full tree in one go when possible.

---

## Part 3 — Deploy on Render

1. Open https://render.com and sign up (GitHub login is easiest).
2. Allow Render to access your GitHub account when asked.
3. Click **New +** → **Web Service**.
4. Find repository `swift-delivery-courier` → **Connect**.
5. Fill in:
   - **Name:** `swift-delivery-courier`
   - **Language / Runtime:** Node
   - **Branch:** `main` (or `master`)
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
6. Instance type: **Free**.
7. Open **Environment** (or Advanced → Environment Variables). Add these **exactly** (names on the left, your values on the right):

| Key | Value |
|-----|--------|
| `NODE_ENV` | `production` |
| `BASE_URL` | leave blank for now; set after first deploy to your `https://….onrender.com` URL |
| `JWT_SECRET` | a long random phrase you invent (20+ characters), e.g. mixed words and numbers — do not reuse your admin password |
| `DATABASE_URL` | the Neon connection string you copied in Part 1 |
| `ADMIN_EMAIL` | the email **you** will use to log in as admin |
| `ADMIN_PASSWORD` | a strong password **you** choose (save it privately) |
| `ADMIN_NAME` | `System Admin` (or your name) |

8. Click **Create Web Service** (or **Deploy**).
9. Wait 5–15 minutes. Status should become **Live**.
10. At the top of the service page, copy the URL like `https://swift-delivery-courier-xxxx.onrender.com`.
11. Edit environment variable `BASE_URL` to that full URL (https, no trailing slash) → **Save**. Render will redeploy.

---

## Part 4 — First use

1. Open your Render URL on your phone.
2. Go to **Login**.
3. Sign in with `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
4. You should see the Admin dashboard.
5. Create a test shipment, add a tracking event, then open **Track** with that tracking number (no login).

---

## Notes

- Free Render apps sleep after idle time; the first open after sleep can take up to a minute.
- Data is stored in Neon Postgres (persistent), not on the web server disk.
- Customers use the same public URL on their phones.
- Never put real secrets in GitHub files—only in Render’s Environment UI.


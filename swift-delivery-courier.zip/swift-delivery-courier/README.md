# Swift Delivery Courier

Production international shipping platform: public tracking, customer accounts (approval required), admin operations, invoices, SQL database.

## Database

| Environment | Engine | How |
|-------------|--------|-----|
| **Production (cloud)** | **PostgreSQL** | Set `DATABASE_URL` (Neon, Supabase, Render Postgres) |
| **Local development** | **SQLite** | File at `DATABASE_PATH` (default `./db/swift.db`) via `better-sqlite3` |

JSON file storage is **not** used for production. Real SQL only.

## Local setup

```bash
cp .env.example .env
# For local: leave DATABASE_URL unset (uses SQLite)
# Set JWT_SECRET and ADMIN_PASSWORD

npm install
npm run seed
npm start
```

Open http://localhost:3000

Admin login: email/password from `.env` (`ADMIN_EMAIL` / `ADMIN_PASSWORD`).

## Free-tier deployment (recommended)

### Stack that works with this project

1. **Web app:** [Render](https://render.com) free Web Service (Node)
2. **Database:** [Neon](https://neon.tech) free PostgreSQL (persistent)

Also compatible:
- **Railway** (web + Postgres)
- **Fly.io** (app + volume or Postgres)
- **Supabase** free Postgres + any Node host
- **Vercel** is a poor fit (serverless; this is a long-running Express app)

### Step-by-step: Render + Neon

#### A. Create free Postgres (Neon)

1. Sign up at https://neon.tech  
2. Create a project  
3. Copy the connection string (`postgresql://...`)  

#### B. Deploy on Render

1. Push this repo to GitHub  
2. Render → **New → Web Service** → connect the repo  
3. Settings:
   - **Runtime:** Node  
   - **Build command:** `npm install`  
   - **Start command:** `npm run seed && npm start`  
     (or run seed once via Shell, then `npm start`)  
4. **Environment variables:**

```
NODE_ENV=production
BASE_URL=https://YOUR-SERVICE.onrender.com
JWT_SECRET=<long random string>
DATABASE_URL=<neon connection string>
ADMIN_EMAIL=admin@yourdomain.com
ADMIN_PASSWORD=<strong password>
```

5. Deploy. After first deploy, open the site, log in as admin, change password if needed.

#### C. Custom domain (optional)

Render → Settings → Custom Domain → add your domain and set DNS.

### Important free-tier notes

- Render free services **spin down** after ~15 minutes idle; first request may take 30–60s.  
- Neon free tier is enough for early traffic; upgrade when needed.  
- Do not use SQLite on Render free disk — it is **ephemeral** (data lost on redeploy). Always use `DATABASE_URL` in production.  
- `better-sqlite3` needs native compile; Render’s Node build environment supports it, but production should still prefer Postgres.

## Test flows after deploy

**Admin**

1. Login → `/login`  
2. Create shipment → `/admin/shipments/new`  
3. Add tracking events on the shipment page  
4. Approve customers under `/admin/customers`  

**Public / customer**

1. Track with number on `/track` (no login)  
2. Register → pending account  
3. Admin approves → customer sees invoices  

## Security checklist before real customers

- [ ] Strong `JWT_SECRET` and admin password  
- [ ] HTTPS (Render provides this)  
- [ ] `DATABASE_URL` only in env vars, never in code  
- [ ] Change default admin credentials  
- [ ] Add Terms / Privacy pages  
- [ ] Connect email + payment provider when ready  

## Project structure

```
server.js, package.json, .env.example
config/          constants, utils, env
db/              database.js, schema.sql, schema.postgres.sql
middleware/      auth
routes/          public, auth, customer, admin
views/           EJS pages
public/          css, js
scripts/seed.js
```

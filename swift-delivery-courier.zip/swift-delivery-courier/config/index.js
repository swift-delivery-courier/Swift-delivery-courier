try { require('dotenv').config(); } catch (e) {}
const path = require('path');

module.exports = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  baseUrl: process.env.BASE_URL || 'http://localhost:3000',
  jwt: {
    secret: process.env.JWT_SECRET || 'dev-only-change-me-in-production-swift-2026',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    cookieName: process.env.SESSION_COOKIE_NAME || 'sdc_token'
  },
  databasePath: process.env.DATABASE_PATH || path.join(__dirname, '..', 'db', 'swift.db'),
  admin: {
    email: process.env.ADMIN_EMAIL || 'admin@swiftdeliverycourier.com',
    password: process.env.ADMIN_PASSWORD || 'ChangeMeNow!2026',
    name: process.env.ADMIN_NAME || 'System Admin'
  }
};

(function () {
  // Mobile nav
  const toggle = document.getElementById('menuToggle');
  const links = document.getElementById('navLinks');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
    });
  }

  // Homepage / ship quote
  const quoteBtn = document.getElementById('quoteBtn');
  if (quoteBtn) {
    quoteBtn.addEventListener('click', async function () {
      const weight = document.getElementById('weight')?.value;
      const service = document.getElementById('service')?.value;
      const from = document.getElementById('from')?.value;
      const to = document.getElementById('to')?.value;
      const result = document.getElementById('quoteResult');
      if (!result) return;

      result.classList.remove('show');
      result.textContent = 'Calculating…';
      result.classList.add('show');

      try {
        const res = await fetch('/api/quote', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ weight: Number(weight), service, from_country: from, to_country: to })
        });
        const data = await res.json();
        if (!res.ok) {
          result.textContent = data.error || 'Unable to calculate quote';
          return;
        }
        result.innerHTML =
          'Estimated quote: <strong>$' + data.amount.toFixed(2) + ' ' + data.currency + '</strong>' +
          (data.estimatedDaysMin != null
            ? ' · Est. delivery ' + data.estimatedDaysMin + '–' + data.estimatedDaysMax + ' days'
            : '') +
          '<br><span style="font-weight:500;font-size:12px">' + (data.note || '') + '</span>';
      } catch (e) {
        result.textContent = 'Network error. Please try again.';
      }
    });
  }

  // Track form redirect
  const trackForm = document.getElementById('trackForm');
  if (trackForm) {
    trackForm.addEventListener('submit', function (e) {
      const input = document.getElementById('tracking');
      if (input && !input.value.trim()) {
        e.preventDefault();
        input.focus();
      }
    });
  }
})();

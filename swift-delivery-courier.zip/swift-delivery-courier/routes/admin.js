const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db/database');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { COUNTRIES, SERVICE_TYPES, PACKAGE_TYPES, SHIPMENT_STATUSES, STATUS_MAP, CURRENCIES } = require('../config/constants');
const { generateTrackingNumber, generateInvoiceNumber, calculateQuote, addDays } = require('../config/utils');

const router = express.Router();
router.use(requireAuth, requireAdmin);

router.get('/', async (req, res, next) => {
  try {
    const stats = {
      customers: (await db.get("SELECT COUNT(*) as c FROM users WHERE role = 'customer'")).c,
      pendingCustomers: (await db.get("SELECT COUNT(*) as c FROM users WHERE role = 'customer' AND status = 'pending'")).c,
      shipments: (await db.get('SELECT COUNT(*) as c FROM shipments')).c,
      activeShipments: (await db.get("SELECT COUNT(*) as c FROM shipments WHERE status NOT IN ('delivered','returned')")).c,
      openTickets: (await db.get("SELECT COUNT(*) as c FROM support_requests WHERE status IN ('open','in_progress')")).c,
      pendingInvoices: (await db.get("SELECT COUNT(*) as c FROM invoices WHERE status = 'pending'")).c
    };
    const recentShipments = await db.all(`
      SELECT tracking_number, status, sender_country, recipient_country, created_at
      FROM shipments ORDER BY created_at DESC LIMIT 8
    `);
    const recentTickets = await db.all(`
      SELECT id, name, subject, request_type, status, created_at
      FROM support_requests ORDER BY created_at DESC LIMIT 8
    `);
    res.render('admin/dashboard', {
      title: 'Admin Dashboard', user: req.user, stats, recentShipments, recentTickets, statusMap: STATUS_MAP
    });
  } catch (e) { next(e); }
});

router.get('/customers', async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    let customers;
    if (q) {
      customers = await db.all(`
        SELECT * FROM users WHERE role = 'customer'
        AND (email LIKE ? OR full_name LIKE ? OR company LIKE ?)
        ORDER BY created_at DESC
      `, [`%${q}%`, `%${q}%`, `%${q}%`]);
    } else {
      customers = await db.all(`SELECT * FROM users WHERE role = 'customer' ORDER BY created_at DESC`);
    }
    res.render('admin/customers', { title: 'Customers', user: req.user, customers, q });
  } catch (e) { next(e); }
});

router.post('/customers/:id/status', async (req, res, next) => {
  try {
    const status = req.body.status;
    if (!['pending', 'approved', 'suspended'].includes(status)) return res.status(400).send('Invalid status');
    await db.run(`UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ? AND role = 'customer'`,
      [status, req.params.id]);
    if (status === 'approved') {
      await db.run(`
        INSERT INTO notifications (user_id, title, body, link)
        VALUES (?, 'Account approved', 'Your Swift Delivery Courier account has been approved. You can now access invoices and full dashboard features.', '/dashboard')
      `, [req.params.id]);
    }
    res.redirect('/admin/customers');
  } catch (e) { next(e); }
});

router.get('/shipments', async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    let shipments;
    if (q) {
      shipments = await db.all(`
        SELECT * FROM shipments
        WHERE tracking_number LIKE ? OR sender_name LIKE ? OR recipient_name LIKE ?
           OR sender_country LIKE ? OR recipient_country LIKE ?
        ORDER BY created_at DESC
      `, [`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`]);
    } else {
      shipments = await db.all('SELECT * FROM shipments ORDER BY created_at DESC LIMIT 200');
    }
    res.render('admin/shipments', { title: 'Shipments', user: req.user, shipments, statusMap: STATUS_MAP, q });
  } catch (e) { next(e); }
});

router.get('/shipments/new', async (req, res, next) => {
  try {
    const customers = await db.all(`
      SELECT id, full_name, email FROM users WHERE role = 'customer' AND status = 'approved' ORDER BY full_name
    `);
    res.render('admin/shipment-form', {
      title: 'Create Shipment', user: req.user, shipment: null, customers,
      countries: COUNTRIES, serviceTypes: SERVICE_TYPES, packageTypes: PACKAGE_TYPES, currencies: CURRENCIES
    });
  } catch (e) { next(e); }
});

router.post('/shipments/new', [
  body('sender_name').trim().notEmpty(),
  body('sender_address').trim().notEmpty(),
  body('sender_country').trim().notEmpty(),
  body('recipient_name').trim().notEmpty(),
  body('recipient_address').trim().notEmpty(),
  body('recipient_country').trim().notEmpty(),
  body('weight_kg').isFloat({ min: 0.1 }),
  body('service_type').isIn(['express', 'standard', 'economy'])
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    const customers = await db.all(`
      SELECT id, full_name, email FROM users WHERE role = 'customer' AND status = 'approved' ORDER BY full_name
    `);
    if (!errors.isEmpty()) {
      return res.status(400).render('admin/shipment-form', {
        title: 'Create Shipment', user: req.user, shipment: req.body, customers,
        countries: COUNTRIES, serviceTypes: SERVICE_TYPES, packageTypes: PACKAGE_TYPES, currencies: CURRENCIES,
        errors: errors.array()
      });
    }
    const tracking = await generateTrackingNumber();
    const quote = await calculateQuote(req.body.weight_kg, req.body.service_type);
    const estDelivery = addDays(new Date(), quote.estimatedDaysMax || 7);
    const customerId = req.body.customer_id ? parseInt(req.body.customer_id, 10) : null;
    const price = req.body.quoted_price ? parseFloat(req.body.quoted_price) : quote.amount;
    const currency = req.body.currency || 'USD';

    const result = await db.run(`
      INSERT INTO shipments (
        tracking_number, customer_id,
        sender_name, sender_phone, sender_email, sender_address, sender_city, sender_state, sender_postal, sender_country,
        recipient_name, recipient_phone, recipient_email, recipient_address, recipient_city, recipient_state, recipient_postal, recipient_country,
        package_type, weight_kg, length_cm, width_cm, height_cm, description,
        service_type, quoted_price, currency, status, current_location, estimated_delivery, notes, created_by
      ) VALUES (
        ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, 'order_received', ?, ?, ?, ?
      )
    `, [
      tracking, customerId,
      req.body.sender_name, req.body.sender_phone || null, req.body.sender_email || null,
      req.body.sender_address, req.body.sender_city || null, req.body.sender_state || null,
      req.body.sender_postal || null, req.body.sender_country,
      req.body.recipient_name, req.body.recipient_phone || null, req.body.recipient_email || null,
      req.body.recipient_address, req.body.recipient_city || null, req.body.recipient_state || null,
      req.body.recipient_postal || null, req.body.recipient_country,
      req.body.package_type || 'parcel', parseFloat(req.body.weight_kg),
      req.body.length_cm ? parseFloat(req.body.length_cm) : null,
      req.body.width_cm ? parseFloat(req.body.width_cm) : null,
      req.body.height_cm ? parseFloat(req.body.height_cm) : null,
      req.body.description || null,
      req.body.service_type, price, currency,
      req.body.sender_city || req.body.sender_country,
      estDelivery, req.body.notes || null, req.user.id
    ]);

    const shipmentId = result.lastInsertRowid;
    await db.run(`
      INSERT INTO tracking_events (shipment_id, status, location, description, created_by)
      VALUES (?, 'order_received', ?, 'Shipment order received and registered in system.', ?)
    `, [shipmentId, req.body.sender_city || req.body.sender_country, req.user.id]);

    if (req.body.create_invoice === '1' && customerId) {
      const invNum = await generateInvoiceNumber();
      await db.run(`
        INSERT INTO invoices (invoice_number, shipment_id, customer_id, amount, currency, status, due_date)
        VALUES (?, ?, ?, ?, ?, 'pending', date('now', '+14 days'))
      `, [invNum, shipmentId, customerId, price, currency]);
      await db.run(`
        INSERT INTO notifications (user_id, title, body, link)
        VALUES (?, 'New invoice', ?, '/dashboard/invoices')
      `, [customerId, `Invoice ${invNum} for shipment ${tracking} has been created.`]);
    }
    if (customerId) {
      await db.run(`
        INSERT INTO notifications (user_id, title, body, link)
        VALUES (?, 'New shipment', ?, ?)
      `, [customerId, `Shipment ${tracking} has been created.`, `/dashboard/shipments/${tracking}`]);
    }
    res.redirect(`/admin/shipments/${tracking}`);
  } catch (e) { next(e); }
});

router.get('/shipments/:tracking', async (req, res, next) => {
  try {
    const shipment = await db.get('SELECT * FROM shipments WHERE tracking_number = ?', [req.params.tracking]);
    if (!shipment) {
      return res.status(404).render('error', { title: 'Not Found', message: 'Shipment not found.', user: req.user });
    }
    const events = await db.all(`
      SELECT te.*, u.full_name as admin_name
      FROM tracking_events te
      LEFT JOIN users u ON u.id = te.created_by
      WHERE te.shipment_id = ?
      ORDER BY te.event_time ASC, te.id ASC
    `, [shipment.id]);
    const invoice = await db.get('SELECT * FROM invoices WHERE shipment_id = ? LIMIT 1', [shipment.id]);
    let customer = null;
    if (shipment.customer_id) {
      customer = await db.get('SELECT id, full_name, email, status FROM users WHERE id = ?', [shipment.customer_id]);
    }
    res.render('admin/shipment-detail', {
      title: `Shipment ${shipment.tracking_number}`, user: req.user, shipment, events, invoice, customer,
      statusMap: STATUS_MAP, statuses: SHIPMENT_STATUSES
    });
  } catch (e) { next(e); }
});

router.post('/shipments/:tracking/update', async (req, res, next) => {
  try {
    const shipment = await db.get('SELECT * FROM shipments WHERE tracking_number = ?', [req.params.tracking]);
    if (!shipment) return res.status(404).send('Not found');
    await db.run(`
      UPDATE shipments SET
        sender_name = ?, sender_phone = ?, sender_email = ?, sender_address = ?,
        sender_city = ?, sender_state = ?, sender_postal = ?, sender_country = ?,
        recipient_name = ?, recipient_phone = ?, recipient_email = ?, recipient_address = ?,
        recipient_city = ?, recipient_state = ?, recipient_postal = ?, recipient_country = ?,
        package_type = ?, weight_kg = ?, length_cm = ?, width_cm = ?, height_cm = ?,
        description = ?, service_type = ?, quoted_price = ?, currency = ?,
        estimated_delivery = ?, notes = ?, updated_at = datetime('now')
      WHERE id = ?
    `, [
      req.body.sender_name, req.body.sender_phone || null, req.body.sender_email || null, req.body.sender_address,
      req.body.sender_city || null, req.body.sender_state || null, req.body.sender_postal || null, req.body.sender_country,
      req.body.recipient_name, req.body.recipient_phone || null, req.body.recipient_email || null, req.body.recipient_address,
      req.body.recipient_city || null, req.body.recipient_state || null, req.body.recipient_postal || null, req.body.recipient_country,
      req.body.package_type, parseFloat(req.body.weight_kg) || shipment.weight_kg,
      req.body.length_cm ? parseFloat(req.body.length_cm) : null,
      req.body.width_cm ? parseFloat(req.body.width_cm) : null,
      req.body.height_cm ? parseFloat(req.body.height_cm) : null,
      req.body.description || null, req.body.service_type,
      req.body.quoted_price ? parseFloat(req.body.quoted_price) : shipment.quoted_price,
      req.body.currency || shipment.currency,
      req.body.estimated_delivery || null, req.body.notes || null, shipment.id
    ]);
    res.redirect(`/admin/shipments/${req.params.tracking}`);
  } catch (e) { next(e); }
});

router.post('/shipments/:tracking/event', [
  body('status').notEmpty()
], async (req, res, next) => {
  try {
    const shipment = await db.get('SELECT * FROM shipments WHERE tracking_number = ?', [req.params.tracking]);
    if (!shipment) return res.status(404).send('Not found');
    const status = req.body.status;
    const location = req.body.location || shipment.current_location;
    const description = req.body.description || STATUS_MAP[status] || status;
    const eventTime = req.body.event_time || null;
    if (eventTime) {
      await db.run(`
        INSERT INTO tracking_events (shipment_id, status, location, description, event_time, created_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [shipment.id, status, location, description, eventTime, req.user.id]);
    } else {
      await db.run(`
        INSERT INTO tracking_events (shipment_id, status, location, description, created_by)
        VALUES (?, ?, ?, ?, ?)
      `, [shipment.id, status, location, description, req.user.id]);
    }
    await db.run(`UPDATE shipments SET status = ?, current_location = ?, updated_at = datetime('now') WHERE id = ?`,
      [status, location, shipment.id]);
    if (shipment.customer_id) {
      await db.run(`
        INSERT INTO notifications (user_id, title, body, link)
        VALUES (?, 'Shipment update', ?, ?)
      `, [shipment.customer_id,
          `${shipment.tracking_number}: ${STATUS_MAP[status] || status}${location ? ' — ' + location : ''}`,
          `/dashboard/shipments/${shipment.tracking_number}`]);
    }
    res.redirect(`/admin/shipments/${req.params.tracking}`);
  } catch (e) { next(e); }
});

router.get('/support', async (req, res, next) => {
  try {
    const statusFilter = req.query.status || '';
    let tickets;
    if (statusFilter) {
      tickets = await db.all(`SELECT * FROM support_requests WHERE status = ? ORDER BY created_at DESC`, [statusFilter]);
    } else {
      tickets = await db.all('SELECT * FROM support_requests ORDER BY created_at DESC');
    }
    res.render('admin/support', { title: 'Support Requests', user: req.user, tickets, statusFilter });
  } catch (e) { next(e); }
});

router.get('/support/:id', async (req, res, next) => {
  try {
    const ticket = await db.get('SELECT * FROM support_requests WHERE id = ?', [req.params.id]);
    if (!ticket) return res.status(404).send('Not found');
    res.render('admin/support-detail', { title: `Ticket #${ticket.id}`, user: req.user, ticket });
  } catch (e) { next(e); }
});

router.post('/support/:id', async (req, res, next) => {
  try {
    await db.run(`UPDATE support_requests SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?`,
      [req.body.status, req.body.admin_notes || null, req.params.id]);
    res.redirect(`/admin/support/${req.params.id}`);
  } catch (e) { next(e); }
});

router.get('/invoices', async (req, res, next) => {
  try {
    const invoices = await db.all(`
      SELECT i.*, s.tracking_number, u.full_name as customer_name, u.email as customer_email
      FROM invoices i
      LEFT JOIN shipments s ON s.id = i.shipment_id
      LEFT JOIN users u ON u.id = i.customer_id
      ORDER BY i.created_at DESC
    `);
    res.render('admin/invoices', { title: 'Invoices', user: req.user, invoices });
  } catch (e) { next(e); }
});

router.post('/invoices/:id/status', async (req, res, next) => {
  try {
    const status = req.body.status;
    if (!['pending', 'paid', 'overdue', 'cancelled'].includes(status)) return res.status(400).send('Invalid');
    if (status === 'paid') {
      await db.run(`UPDATE invoices SET status = ?, paid_at = datetime('now'), payment_reference = COALESCE(?, payment_reference), updated_at = datetime('now') WHERE id = ?`,
        [status, req.body.payment_reference || null, req.params.id]);
    } else {
      await db.run(`UPDATE invoices SET status = ?, payment_reference = COALESCE(?, payment_reference), updated_at = datetime('now') WHERE id = ?`,
        [status, req.body.payment_reference || null, req.params.id]);
    }
    res.redirect('/admin/invoices');
  } catch (e) { next(e); }
});

router.get('/rates', async (req, res, next) => {
  try {
    const rates = await db.all('SELECT * FROM shipping_rates ORDER BY service_type');
    res.render('admin/rates', { title: 'Shipping Rates', user: req.user, rates });
  } catch (e) { next(e); }
});

router.post('/rates', async (req, res, next) => {
  try {
    for (const s of ['express', 'standard', 'economy']) {
      const base = parseFloat(req.body[`base_${s}`]);
      const perKg = parseFloat(req.body[`perkg_${s}`]);
      const mult = parseFloat(req.body[`mult_${s}`]) || 1;
      const minD = parseInt(req.body[`min_${s}`], 10) || null;
      const maxD = parseInt(req.body[`max_${s}`], 10) || null;
      if (!isNaN(base) && !isNaN(perKg)) {
        await db.run(`
          UPDATE shipping_rates SET base_fee = ?, per_kg_rate = ?, multiplier = ?,
          estimated_days_min = ?, estimated_days_max = ?, updated_at = datetime('now')
          WHERE service_type = ?
        `, [base, perKg, mult, minD, maxD, s]);
      }
    }
    res.redirect('/admin/rates');
  } catch (e) { next(e); }
});

module.exports = router;

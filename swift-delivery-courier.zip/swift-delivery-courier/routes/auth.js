const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../db/database');
const { signToken, setAuthCookie, clearAuthCookie } = require('../middleware/auth');

const router = express.Router();

router.get('/login', (req, res) => {
  if (req.user) return res.redirect(req.user.role === 'admin' ? '/admin' : '/dashboard');
  res.render('auth/login', { title: 'Login', user: null, next: req.query.next || '' });
});

router.post('/login', [
  body('email').trim().isEmail().normalizeEmail(),
  body('password').notEmpty()
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/login', {
        title: 'Login', user: null, error: 'Invalid email or password', next: req.body.next || ''
      });
    }
    const user = await db.get('SELECT * FROM users WHERE email = ?', [req.body.email]);
    if (!user || !bcrypt.compareSync(req.body.password, user.password_hash)) {
      return res.status(401).render('auth/login', {
        title: 'Login', user: null, error: 'Invalid email or password', next: req.body.next || ''
      });
    }
    if (user.status === 'suspended') {
      return res.status(403).render('auth/login', {
        title: 'Login', user: null, error: 'This account has been suspended. Contact support.', next: req.body.next || ''
      });
    }
    setAuthCookie(res, signToken(user.id));
    res.redirect(req.body.next || (user.role === 'admin' ? '/admin' : '/dashboard'));
  } catch (e) { next(e); }
});

router.get('/logout', (req, res) => {
  clearAuthCookie(res);
  res.redirect('/');
});

router.get('/register', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  res.render('auth/register', { title: 'Request an Account', user: null });
});

router.post('/register', [
  body('email').trim().isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('full_name').trim().notEmpty().isLength({ max: 120 }),
  body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 40 }),
  body('company').optional({ checkFalsy: true }).trim().isLength({ max: 120 })
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('auth/register', {
        title: 'Request an Account', user: null, errors: errors.array(), form: req.body
      });
    }
    const existing = await db.get('SELECT id FROM users WHERE email = ?', [req.body.email]);
    if (existing) {
      return res.status(400).render('auth/register', {
        title: 'Request an Account', user: null,
        error: 'An account with this email already exists. Please log in or contact support.',
        form: req.body
      });
    }
    const hash = bcrypt.hashSync(req.body.password, 12);
    const result = await db.run(`
      INSERT INTO users (email, password_hash, full_name, phone, company, role, status)
      VALUES (?, ?, ?, ?, ?, 'customer', 'pending')
    `, [req.body.email, hash, req.body.full_name, req.body.phone || null, req.body.company || null]);

    await db.run(`
      INSERT INTO support_requests (name, email, phone, subject, message, request_type)
      VALUES (?, ?, ?, ?, ?, 'account_request')
    `, [req.body.full_name, req.body.email, req.body.phone || null,
        'New account registration request',
        `Customer registered via website.\nCompany: ${req.body.company || 'N/A'}`]);

    setAuthCookie(res, signToken(result.lastInsertRowid));
    res.redirect('/dashboard?registered=1');
  } catch (e) { next(e); }
});

module.exports = router;

const express = require('express');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const { requireAuth, requireApprovedCustomer } = require('../middleware/auth');
const { STATUS_MAP, SHIPMENT_STATUSES } = require('../config/constants');

const router = express.Router();
router.use(requireAuth);

router.get('/dashboard', async (req, res, next) => {
  try {
    const userId = req.user.id;
    const activeShipments = await db.all(`
      SELECT tracking_number, status, recipient_country, estimated_delivery, updated_at
      FROM shipments WHERE customer_id = ? AND status NOT IN ('delivered', 'returned')
      ORDER BY updated_at DESC LIMIT 10
    `, [userId]);
    const recentShipments = await db.all(`
      SELECT tracking_number, status, recipient_country, created_at
      FROM shipments WHERE customer_id = ? ORDER BY created_at DESC LIMIT 15
    `, [userId]);
    const invoices = await db.all(`
      SELECT invoice_number, amount, currency, status, due_date, created_at
      FROM invoices WHERE customer_id = ? ORDER BY created_at DESC LIMIT 10
    `, [userId]);
    const notifications = await db.all(`
      SELECT id, title, body, link, is_read, created_at
      FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
    `, [userId]);
    const unreadCount = notifications.filter(n => !n.is_read).length;
    res.render('customer/dashboard', {
      title: 'My Dashboard', user: req.user, activeShipments, recentShipments,
      invoices, notifications, unreadCount, statusMap: STATUS_MAP,
      registered: req.query.registered === '1'
    });
  } catch (e) { next(e); }
});

router.get('/dashboard/profile', (req, res) => {
  res.render('customer/profile', { title: 'My Profile', user: req.user });
});

router.post('/dashboard/profile', [
  body('full_name').trim().notEmpty().isLength({ max: 120 }),
  body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 40 }),
  body('company').optional({ checkFalsy: true }).trim().isLength({ max: 120 })
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('customer/profile', { title: 'My Profile', user: req.user, errors: errors.array() });
    }
    await db.run(`UPDATE users SET full_name = ?, phone = ?, company = ?, updated_at = datetime('now') WHERE id = ?`,
      [req.body.full_name, req.body.phone || null, req.body.company || null, req.user.id]);
    req.user.full_name = req.body.full_name;
    req.user.phone = req.body.phone;
    req.user.company = req.body.company;
    res.render('customer/profile', { title: 'My Profile', user: req.user, success: 'Profile updated.' });
  } catch (e) { next(e); }
});

router.post('/dashboard/password', [
  body('current_password').notEmpty(),
  body('new_password').isLength({ min: 8 })
], async (req, res, next) => {
  try {
    const user = await db.get('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    if (!bcrypt.compareSync(req.body.current_password, user.password_hash)) {
      return res.status(400).render('customer/profile', {
        title: 'My Profile', user: req.user, error: 'Current password is incorrect'
      });
    }
    const hash = bcrypt.hashSync(req.body.new_password, 12);
    await db.run(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`, [hash, req.user.id]);
    res.render('customer/profile', { title: 'My Profile', user: req.user, success: 'Password changed successfully.' });
  } catch (e) { next(e); }
});

router.get('/dashboard/shipments', async (req, res, next) => {
  try {
    const shipments = await db.all(`SELECT * FROM shipments WHERE customer_id = ? ORDER BY created_at DESC`, [req.user.id]);
    res.render('customer/shipments', { title: 'My Shipments', user: req.user, shipments, statusMap: STATUS_MAP });
  } catch (e) { next(e); }
});

router.get('/dashboard/shipments/:tracking', async (req, res, next) => {
  try {
    const shipment = await db.get(`SELECT * FROM shipments WHERE tracking_number = ? AND customer_id = ?`,
      [req.params.tracking, req.user.id]);
    if (!shipment) {
      return res.status(404).render('error', {
        title: 'Not Found', message: 'Shipment not found or you do not have access.', user: req.user
      });
    }
    const events = await db.all(`SELECT * FROM tracking_events WHERE shipment_id = ? ORDER BY event_time ASC, id ASC`, [shipment.id]);
    const invoice = await db.get(`SELECT * FROM invoices WHERE shipment_id = ? LIMIT 1`, [shipment.id]);
    res.render('customer/shipment-detail', {
      title: `Shipment ${shipment.tracking_number}`, user: req.user, shipment, events, invoice,
      statusMap: STATUS_MAP, statuses: SHIPMENT_STATUSES
    });
  } catch (e) { next(e); }
});

router.get('/dashboard/invoices', requireApprovedCustomer, async (req, res, next) => {
  try {
    const invoices = await db.all(`
      SELECT i.*, s.tracking_number FROM invoices i
      LEFT JOIN shipments s ON s.id = i.shipment_id
      WHERE i.customer_id = ? ORDER BY i.created_at DESC
    `, [req.user.id]);
    res.render('customer/invoices', { title: 'Invoices & Payments', user: req.user, invoices });
  } catch (e) { next(e); }
});

router.get('/dashboard/support', (req, res) => {
  res.render('customer/support', { title: 'Support', user: req.user });
});

router.post('/dashboard/notifications/:id/read', async (req, res, next) => {
  try {
    await db.run('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    res.redirect('back');
  } catch (e) { next(e); }
});

module.exports = router;

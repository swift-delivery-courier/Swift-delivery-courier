const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db/database');
const { COUNTRIES, SERVICE_TYPES, PACKAGE_TYPES, STATUS_MAP, SHIPMENT_STATUSES } = require('../config/constants');
const { calculateQuote } = require('../config/utils');

const router = express.Router();

router.get('/', (req, res) => {
  res.render('home', {
    title: 'Swift Delivery Courier — Ship Worldwide',
    user: req.user,
    countries: COUNTRIES,
    serviceTypes: SERVICE_TYPES
  });
});

router.get('/track', async (req, res, next) => {
  try {
    const tracking = (req.query.number || '').trim().toUpperCase();
    let shipment = null;
    let events = [];
    if (tracking) {
      shipment = await db.get(`
        SELECT tracking_number, status, current_location, estimated_delivery,
               sender_country, recipient_country, sender_city, recipient_city,
               service_type, weight_kg, created_at, updated_at
        FROM shipments WHERE tracking_number = ?
      `, [tracking]);
      if (shipment) {
        const full = await db.get('SELECT id FROM shipments WHERE tracking_number = ?', [tracking]);
        events = await db.all(`
          SELECT status, location, description, event_time
          FROM tracking_events WHERE shipment_id = ?
          ORDER BY event_time ASC, id ASC
        `, [full.id]);
      }
    }
    res.render('track', {
      title: tracking ? `Track ${tracking}` : 'Track Shipment',
      user: req.user, tracking, shipment, events,
      statusMap: STATUS_MAP, statuses: SHIPMENT_STATUSES
    });
  } catch (e) { next(e); }
});

router.get('/services', (req, res) => {
  res.render('services', { title: 'Shipping Services', user: req.user });
});

router.get('/about', (req, res) => {
  res.render('about', { title: 'About Us', user: req.user });
});

router.get('/contact', (req, res) => {
  res.render('contact', { title: 'Contact & Support', user: req.user, query: req.query });
});

router.post('/contact', [
  body('name').trim().notEmpty().isLength({ max: 120 }),
  body('email').trim().isEmail().normalizeEmail(),
  body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 40 }),
  body('subject').trim().notEmpty().isLength({ max: 200 }),
  body('message').trim().notEmpty().isLength({ max: 5000 }),
  body('request_type').isIn(['account_request', 'shipment_support', 'general', 'quote']),
  body('related_tracking').optional({ checkFalsy: true }).trim().isLength({ max: 40 })
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render('contact', {
        title: 'Contact & Support', user: req.user, errors: errors.array(), form: req.body, query: {}
      });
    }
    await db.run(`
      INSERT INTO support_requests (name, email, phone, subject, message, request_type, related_tracking)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [req.body.name, req.body.email, req.body.phone || null, req.body.subject,
        req.body.message, req.body.request_type, req.body.related_tracking || null]);
    res.render('contact', { title: 'Contact & Support', user: req.user, success: true, query: {} });
  } catch (e) { next(e); }
});

router.post('/api/quote', [
  body('weight').isFloat({ min: 0.1 }),
  body('service').isIn(['express', 'standard', 'economy'])
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });
  try {
    const quote = await calculateQuote(req.body.weight, req.body.service);
    res.json({
      amount: quote.amount, currency: quote.currency,
      estimatedDaysMin: quote.estimatedDaysMin, estimatedDaysMax: quote.estimatedDaysMax,
      note: 'Estimate only. Final price may vary based on dimensions, zone, and customs.'
    });
  } catch (e) {
    res.status(500).json({ error: 'Quote unavailable' });
  }
});

router.get('/ship', (req, res) => {
  res.render('ship', {
    title: 'Get a Shipping Quote', user: req.user,
    countries: COUNTRIES, serviceTypes: SERVICE_TYPES, packageTypes: PACKAGE_TYPES
  });
});

module.exports = router;

#!/usr/bin/env node
try { require('dotenv').config(); } catch (e) {}
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const config = require('../config');

async function main() {
  await db.init();

  const rates = [
    { service_type: 'express', base_fee: 28, per_kg_rate: 9.5, multiplier: 1, estimated_days_min: 2, estimated_days_max: 5 },
    { service_type: 'standard', base_fee: 18, per_kg_rate: 7.5, multiplier: 1, estimated_days_min: 4, estimated_days_max: 10 },
    { service_type: 'economy', base_fee: 12, per_kg_rate: 5.5, multiplier: 1, estimated_days_min: 7, estimated_days_max: 14 }
  ];

  for (const r of rates) {
    const existing = await db.get('SELECT id FROM shipping_rates WHERE service_type = ?', [r.service_type]);
    if (existing) {
      await db.run(`
        UPDATE shipping_rates SET base_fee = ?, per_kg_rate = ?, multiplier = ?,
        estimated_days_min = ?, estimated_days_max = ?, updated_at = datetime('now')
        WHERE service_type = ?
      `, [r.base_fee, r.per_kg_rate, r.multiplier, r.estimated_days_min, r.estimated_days_max, r.service_type]);
    } else {
      await db.run(`
        INSERT INTO shipping_rates (service_type, base_fee, per_kg_rate, multiplier, estimated_days_min, estimated_days_max)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [r.service_type, r.base_fee, r.per_kg_rate, r.multiplier, r.estimated_days_min, r.estimated_days_max]);
    }
  }
  console.log('Shipping rates seeded.');

  const existing = await db.get('SELECT id FROM users WHERE email = ?', [config.admin.email]);
  if (existing) {
    console.log('Admin already exists:', config.admin.email);
  } else {
    const hash = bcrypt.hashSync(config.admin.password, 12);
    await db.run(`
      INSERT INTO users (email, password_hash, full_name, role, status)
      VALUES (?, ?, ?, 'admin', 'approved')
    `, [config.admin.email, hash, config.admin.name]);
    console.log('Admin created:', config.admin.email);
    console.log('Password:', config.admin.password);
    console.log('CHANGE THIS PASSWORD after first login.');
  }

  await db.close();
  console.log('Seed complete.');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
